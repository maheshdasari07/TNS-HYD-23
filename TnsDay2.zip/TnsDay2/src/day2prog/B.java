package day2prog;

public class B {
	int a = 10;
	static int b = 40;
	int display() {
		return 10; 
	}
	
	static void display1() {
		System.out.println(10);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		B b1 = new B();
		System.out.println(b1.a);
		
		System.out.println(B.b);
		B.display1();
	}

	
}
