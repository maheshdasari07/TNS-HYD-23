package day2prog;

public class P {
	//private void display(){
	//void display(){
	//protacted void display(){
	public void display() {
		
		//System.out.println("PRIVATE ACCESS MODIFIER");
		//System.out.println("DEFULT ACCESS MODIFIER");
		//System.out.println("PROTACTED ACCESS MODIFIER");
		System.out.println("PUBLIC ACCESS MODIFIER");
		
	}

}
