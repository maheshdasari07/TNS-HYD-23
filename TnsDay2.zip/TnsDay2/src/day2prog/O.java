package day2prog;

public class O {

	public static void main(String[] args) {
		N n1 = new N();
		System.out.println(n1.a);
		System.out.println(N.b);
		n1.display();
		N.display1();

	}

}
