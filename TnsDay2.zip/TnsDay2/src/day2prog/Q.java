package day2prog;

public class Q {

	public static void main(String[] args) {
		P p1 = new P();
		p1.display();

	}

}
